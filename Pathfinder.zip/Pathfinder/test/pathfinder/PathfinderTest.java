/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package pathfinder;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author imshahad
 */
public class PathfinderTest {
    
    public PathfinderTest() {
    }
    
    @BeforeAll
    public static void setUpClass() {
    }
    
    @AfterAll
    public static void tearDownClass() {
    }
    
    @BeforeEach
    public void setUp() {
    }
    
    @AfterEach
    public void tearDown() {
    }

    /**
     * Test of F1panelbuild method, of class Pathfinder.
     */
    @Test
    public void testF1panelbuild() {
        System.out.println("F1panelbuild");
        Pathfinder instance = new Pathfinder();
        instance.F1panelbuild();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of Flogpanelbuild method, of class Pathfinder.
     */
    @Test
    public void testFlogpanelbuild() {
        System.out.println("Flogpanelbuild");
        Pathfinder instance = new Pathfinder();
        instance.Flogpanelbuild();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of FileReader method, of class Pathfinder.
     */
    @Test
    public void testFileReader() {
        System.out.println("FileReader");
        String file = "";
        Pathfinder instance = new Pathfinder();
        instance.FileReader(file);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of F2panelbuild method, of class Pathfinder.
     */
    @Test
    public void testF2panelbuild() {
        System.out.println("F2panelbuild");
        Pathfinder instance = new Pathfinder();
        instance.F2panelbuild();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of F3panelBuild method, of class Pathfinder.
     */
    @Test
    public void testF3panelBuild() {
        System.out.println("F3panelBuild");
        Pathfinder instance = new Pathfinder();
        instance.F3panelBuild();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of mbti method, of class Pathfinder.
     */
    @Test
    public void testMbti() {
        System.out.println("mbti");
        Pathfinder instance = new Pathfinder();
        instance.mbti();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Pathfinder.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Pathfinder.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
