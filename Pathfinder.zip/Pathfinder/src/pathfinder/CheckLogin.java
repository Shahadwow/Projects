
package pathfinder;

public class CheckLogin {
    
public boolean checkUserPass (String user, String pass ){
    
    if(user.equals("Heba33") & pass.equals("HebaAhmed")){
       return true;
    }
    
    else if ( user.equals("Shahad") & pass.equals("Shahad12345")){
    return true;
    
    }
    
    else
        return false;
    }
    

}
